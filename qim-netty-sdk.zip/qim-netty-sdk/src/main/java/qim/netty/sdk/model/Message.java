package qim.netty.sdk.model;

import qim.netty.sdk.util.JsonUtil;

public class Message extends Packet {

    //信息类型，
    private final long ID = -6990758301642260480L;

    private int fromId; //来源ID
    private int toId;   //目标ID
    private long chatTime; //消息创建时间long类型
    private byte contentType; //消息类型int类型(0:text、1:image、2:voice、3:vedio、4:music、5:news)
    private byte chatType; //聊天类型int类型(0:未知,1:公聊,2:私聊)"
    private int groupId; //群组id仅在chatType为(1)时需要,String类型
    private String content; //内容

    public int getFromId() {
        return fromId;
    }

    public void setFromId(int fromId) {
        this.fromId = fromId;
    }

    public int getToId() {
        return toId;
    }

    public void setToId(int toId) {
        this.toId = toId;
    }


    public long getChatTime() {
        return chatTime;
    }

    public void setChatTime(long createTime) {
        this.chatTime = createTime;
    }

    public byte getContentType() {
        return contentType;
    }

    public void setContentType(byte contentType) {
        this.contentType = contentType;
    }

    public byte getChatType() {
        return chatType;
    }

    public void setChatType(byte chatType) {
        this.chatType = chatType;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }


    public static class Builder extends Packet.Builder<Message,Message.Builder>{

        public Message msgObj = null;

        @Override
        public Message getObj() {
            return this.msgObj;
        }

        @Override
        public byte[] build(Message obj) {
            msgObj = new Message();
            msgObj.fromId = obj.fromId;
            msgObj.toId = obj.toId;
            msgObj.chatTime = obj.chatTime;
            msgObj.contentType = obj.contentType;
            msgObj.chatType = obj.chatType;
            msgObj.groupId = obj.groupId;
            msgObj.content = obj.content;

            return JsonUtil.toJsonBytes(msgObj);
        }


    }

}
